export class Editorial{
  id?:number;
  nombre?:string;
}
