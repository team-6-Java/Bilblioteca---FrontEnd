export class Perfil {
  username?: string;
  nombre?: string;
  apellido?: string;
  email?: string;
  contraseña?: string;
  descripcion?: string;
  imagen?: string;




}
