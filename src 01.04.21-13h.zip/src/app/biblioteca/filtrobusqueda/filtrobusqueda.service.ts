import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FiltrobusquedaService {

Busqueda: string='';
Filtro: string='';

  constructor() { }
}
