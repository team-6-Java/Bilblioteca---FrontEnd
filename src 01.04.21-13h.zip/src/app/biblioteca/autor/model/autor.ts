export class Autor{
  id?:number;
  nombre?:string;
  apellido?:string;
}
