import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PerfilComponent } from './biblioteca/perfil/perfil.component';
import { MibibliotecaComponent } from './biblioteca/mibiblioteca/mibiblioteca.component';
import { BusquedaLibrosComponent } from './biblioteca/busqueda-libros/busqueda-libros.component';
import { RegistrarLibroComponent } from './biblioteca/registrar-libro/registrar-libro.component';
import { ModificarPerfilComponent } from './biblioteca/modificar-perfil/modificar-perfil.component';
import { AyudaComponent } from './biblioteca/ayuda/ayuda.component';
import { AcercaDeComponent } from './biblioteca/acerca-de/acerca-de.component';
import { ChatComponent } from './biblioteca/chat/chat.component';

@NgModule({
  declarations: [
    AppComponent,
    PerfilComponent,
    MibibliotecaComponent,
    BusquedaLibrosComponent,
    RegistrarLibroComponent,
    ModificarPerfilComponent,
    AyudaComponent,
    AcercaDeComponent,
    ChatComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
