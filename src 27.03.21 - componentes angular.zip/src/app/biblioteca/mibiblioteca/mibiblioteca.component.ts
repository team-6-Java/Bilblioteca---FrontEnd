import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mibiblioteca',
  templateUrl: './mibiblioteca.component.html',
  styleUrls: ['./mibiblioteca.component.css']
})
export class MibibliotecaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
