export class Perfil {
username: string;
nombre: string;
apellido: string;
email: string;
contraseña: string;
imagen: string;
descripcion: string;
activo: boolean;

}
