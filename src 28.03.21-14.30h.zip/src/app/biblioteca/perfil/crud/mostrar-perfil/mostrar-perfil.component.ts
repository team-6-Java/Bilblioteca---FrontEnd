import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mostrar-perfil',
  templateUrl: './mostrar-perfil.component.html',
  styleUrls: ['./mostrar-perfil.component.css']
})
export class MostrarPerfilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
