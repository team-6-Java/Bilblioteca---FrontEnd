import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Perfil } from '../../model/perfil';
import { PerfilService } from '../../service/perfil.service';

@Component({
  selector: 'app-create-perfil',
  templateUrl: './create-perfil.component.html',
  styleUrls: ['./create-perfil.component.css']
})
export class CreatePerfilComponent implements OnInit {

  perfil: Perfil = new Perfil();
  submitted = false;

  constructor(private perfilService: PerfilService,
    private router: Router) { }

  ngOnInit() {
  }

  newPerfil(): void {
    this.submitted = false;
    this.perfil = new Perfil();
  }

  save() {
    this.perfilService
    .createPerfil(this.perfil).subscribe(data => {
      console.log(data)
      this.perfil = new Perfil();
      this.gotoList();
    },
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }

  gotoList() {
    this.router.navigate(['/perfils']);
  }
}
