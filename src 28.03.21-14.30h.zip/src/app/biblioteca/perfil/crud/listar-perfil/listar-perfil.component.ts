import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Perfil } from '../../model/perfil';
import { PerfilService } from '../../service/perfil.service';

@Component({
  selector: 'app-listar-perfil',
  templateUrl: './listar-perfil.component.html',
  styleUrls: ['./listar-perfil.component.css']
})
export class ListarPerfilComponent implements OnInit {
  perfils: Observable<Perfil[]>;

  constructor(private perfilService: PerfilService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.perfils = this.perfilService.getPerfilList();
  }

  deletePerfil(id: string) {
    this.perfilService.deletePerfil(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  perfilDetails(id: string){
    this.router.navigate(['details', id]);
  }

  updatePerfil(id: string){
    this.router.navigate(['update', id]);
  }
}
