export class perfil {
id:string;
nombre: string;
apellido: string;
email: string;
contraseña: string;
imagen: string;
descripcion: string;
activo: boolean;

}
