import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actualizar-perfil',
  templateUrl: './actualizar-perfil.component.html',
  styleUrls: ['./actualizar-perfil.component.css']
})
export class ActualizarPerfilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
