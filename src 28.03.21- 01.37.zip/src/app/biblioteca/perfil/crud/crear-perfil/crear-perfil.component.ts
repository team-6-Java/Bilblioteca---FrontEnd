import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-perfil',
  templateUrl: './crear-perfil.component.html',
  styleUrls: ['./crear-perfil.component.css']
})
export class CrearPerfilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
