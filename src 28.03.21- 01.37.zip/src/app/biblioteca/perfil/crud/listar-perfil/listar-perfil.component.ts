import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listar-perfil',
  templateUrl: './listar-perfil.component.html',
  styleUrls: ['./listar-perfil.component.css']
})
export class ListarPerfilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
