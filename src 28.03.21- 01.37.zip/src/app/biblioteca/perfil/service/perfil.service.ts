import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TokenStorageService } from '../../login/_services/token-storage.service';
import { getLocaleDateFormat } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class PerfilService {
  private baseUrl =
    'http://82.223.78.142:8080/biblioteca/biblioteca/content/Perfil';

  constructor(private http: HttpClient, private token: TokenStorageService) {}

  getPerfil(id: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createPerfil(Perfil: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, Perfil);
  }

  updatePerfil(id: string, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deletePerfil(id: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getPerfilList(): Observable<any> {
    var reqHeader = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + this.token.getToken()
   });
    return this.http.get(this.baseUrl, {headers: reqHeader});
  }
}

