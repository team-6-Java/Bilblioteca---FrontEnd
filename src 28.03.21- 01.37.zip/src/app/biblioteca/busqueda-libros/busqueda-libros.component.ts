import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-busqueda-libros',
  templateUrl: './busqueda-libros.component.html',
  styleUrls: ['./busqueda-libros.component.css']
})
export class BusquedaLibrosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
