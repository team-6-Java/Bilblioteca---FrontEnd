import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modificar-perfil',
  templateUrl: './modificar-perfil.component.html',
  styleUrls: ['./modificar-perfil.component.css']
})
export class ModificarPerfilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
