import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrar-libro',
  templateUrl: './registrar-libro.component.html',
  styleUrls: ['./registrar-libro.component.css']
})
export class RegistrarLibroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
